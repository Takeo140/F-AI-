from ftheory.logic import Law
l = Law('example')
print('Law is_consistent:', l.is_consistent())
